import React from 'react';
import { View, Text } from 'react-native';

export default function DetailsScreen({ route }) {
  const { user } = route.params;

  return (
    <View style={{ padding: 20 }}>
      <Text>{user.name}</Text>
      <Text>{user.email}</Text>
      <Text>{user.phone}</Text>
      <Text>{user.website}</Text>
    </View>
  );
}
